<?php
$configArray = [
    "dns" => "mysql:host=localhost;dbname=usersapi",
    "username" => "root",
    "password" => ""
];
?>